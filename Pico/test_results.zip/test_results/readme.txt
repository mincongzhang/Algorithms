1. Put Pico.exe in the same folder with CSV files. 
2. Run it. 